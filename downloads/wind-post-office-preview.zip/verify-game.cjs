'use strict';
// Puzzle constraints, sequential game progression, restore safety and UI actions.
// This is a Node test with a small document adapter, not a real browser test.
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const vm=require('node:vm');
const D=require('./dist/data.js'),E=require('./dist/engine.js');
let checks=0;
function check(name,fn){fn();checks++;console.log('PASS '+name);}
function permute(list){if(list.length===0)return [[]];return list.flatMap((x,i)=>permute(list.filter((_,j)=>j!==i)).map(r=>[x,...r]));}
function rows(id){const html=D.documents.find(d=>d.id===id).html;return [...html.matchAll(/<tbody>([\s\S]*?)<\/tbody>/g)].flatMap(x=>[...x[1].matchAll(/<tr>([\s\S]*?)<\/tr>/g)].map(r=>[...r[1].matchAll(/<td>([\s\S]*?)<\/td>/g)].map(c=>c[1].replace(/<[^>]+>/g,''))));}
const number=s=>Number(String(s).replace(/[^\d]/g,''));
const minutes=s=>{const [h,m]=s.split(':').map(Number);return h*60+m;};
const clock=n=>String(Math.floor(n/60)).padStart(2,'0')+':'+String(n%60).padStart(2,'0');
let answers={};
check('All source IDs, letter links and unlock stages are valid',()=>{
 assert.equal(new Set(D.documents.map(d=>d.id)).size,D.documents.length);
 assert.equal(D.documents.length,18);assert.equal(D.letters.length,5);
 for(const l of D.letters){assert.equal(l.hints.length,3);for(const id of l.sources){const d=D.documents.find(d=>d.id===id);assert.ok(d);assert.ok(d.stage<=l.id);}}
});
check('Letter 1: all 720 queue orders yield one recipient and receipt',()=>{
 const orders=permute(D.people.map(p=>p.id)).filter(p=>{const i=n=>p.indexOf(n);return i('taeo')===i('daeun')+1&&i('haejun')===i('daeun')+3&&i('haejun')===i('dohyun')+4&&i('sora')===i('taeo')+1&&i('yunseul')===5;});
 assert.equal(orders.length,1);
 const fig=rows('bakery-menu').find(r=>r[2].includes('무화과 세 조각'));assert.ok(fig);const price=number(fig[1]);
 const candidates=rows('receipts').filter(r=>number(r[2])%price===0);assert.equal(candidates.length,1);
 const [order,time,total]=candidates[0];answers[1]={person:orders[0][Number(order)-1],receipt:time,bread:fig[0],quantity:String(number(total)/price)};
 assert.ok(E.validateAnswer(1,answers[1]));assert.equal(answers[1].quantity,'2');
});
check('Letter 2: rotating the printed old grid yields one current parcel',()=>{
 const old=Array.from({length:5},(_,r)=>Array.from('가나다라마',c=>c+(r+1)));
 const destination=old[3-2][3+1];
 // Rotate actual cells counter-clockwise rather than repeat the engine formula.
 const rotated=old[0].map((_,i)=>old.map(row=>row[4-i]));
 let matches=[];rotated.forEach((row,r)=>row.forEach((cell,c)=>{if(cell===destination)matches.push(String.fromCharCode(65+c)+(r+1));}));
 assert.equal(matches.length,1);assert.equal(rotated[3][2],'나3');assert.equal(rotated[1][3],'라4');
 answers[2]={oldCell:destination,cell:matches[0],address:D.addresses[matches[0]].address};assert.ok(E.validateAnswer(2,answers[2]));
 assert.equal(new Set(Object.keys(D.addresses).map(E.newToOld)).size,25);
 for(const key of Object.keys(D.addresses))assert.equal(E.oldToNew(E.newToOld(key)),key);
});
check('Letter 3: all advertised buses have exactly one feasible earliest plan',()=>{
 const walks=Object.fromEntries(rows('walking').slice(0,3).map(r=>[r[0].split(' → ')[1].replace(' 정류장',''),number(r[1])]));
 const valid=[];
 for(const row of rows('bus')){const [name,days,stop,depart,arrive]=row;if(days.includes('토 휴무'))continue;
  const canBoard=840+walks[stop]<=minutes(depart);const enter=Math.max(minutes(arrive),minutes('14:40'));
  const reach=enter+8+5;const deliver=Math.max(reach,minutes('14:58'));const finish=deliver+4;const back=finish+5+8;
  if(canBoard&&finish<=minutes('15:04')&&back<=minutes('15:16'))valid.push({name,depart,deliver:clock(deliver),back:clock(back)});
 }
 assert.equal(valid.length,1);assert.equal(valid[0].name,'마을 2편');answers[3]={bus:'village2',departure:valid[0].depart,delivery:valid[0].deliver,back:valid[0].back};assert.ok(E.validateAnswer(3,answers[3]));
});
check('Letter 4: photos, people and keepsakes each have a unique reconstruction',()=>{
 const log=rows('maintenance');const dated=rows('photos').map(p=>{const features=p[1].split(' / ').map(s=>s.replace(' 깃발','').replace('전시창 ','').replace('가마 ',''));const matches=log.filter(r=>r.slice(1).every((v,i)=>v===features[i]));assert.equal(matches.length,1);return {photo:p[0],day:Number(matches[0][0].match(/월 (\d+)/)[1]),char:p[2]};}).sort((a,b)=>a.day-b.day);
 const order=dated.map(p=>p.photo).join(''),token=dated.map(p=>p.char).join('');
 const people=permute(['daeun','haejun','taeo','yunseul','dohyun']).filter(p=>{const i=n=>p.indexOf(n);return i('daeun')===i('haejun')+1&&i('taeo')===i('yunseul')-1&&[0,4].includes(i('dohyun'))&&![0,4].includes(i('haejun'))&&i('yunseul')===i('dohyun')+2;});
 const tokens=permute(['조개목걸이','노란리본','은색열쇠','푸른단추','종이별']).filter(p=>p[0]==='조개목걸이'&&p[4]==='노란리본'&&p.indexOf('은색열쇠')===p.indexOf('푸른단추')-1&&p.indexOf('종이별')===p.indexOf('푸른단추')+1);
 assert.equal(people.length,1);assert.equal(tokens.length,1);const slot=tokens[0].indexOf(token);const places=rows('promises-people')[0].slice(1);
 answers[4]={order,token,person:people[0][slot],place:places[slot]};assert.ok(E.validateAnswer(4,answers[4]));
});
check('Final invitation resolves from earlier answers and actual opening hours',()=>{
 const indices=[Number(answers[1].quantity),Number(answers[2].oldCell[1]),4,3];
 const cards=D.letters.slice(0,4).map((l,i)=>({open:D.people.find(p=>p.name===l.reply.name).open,part:l.reply.card.lines[indices[i]-1]})).sort((a,b)=>a.open.localeCompare(b.open));
 answers[5]={cell:cards[0].part,gate:cards[1].part,time:cards[2].part+':'+cards[3].part};
 assert.ok(E.validateAnswer(5,answers[5]));assert.equal(D.addresses[answers[5].cell].landmark,'너울정원');
});
check('Locked puzzles reject submissions, wrong answers preserve progress and drafts',()=>{
 const s=E.initial();s.started=true;assert.equal(E.submit(s,3,answers[3]).reason,'locked');assert.deepEqual(s.completed,[]);
 const wrong={...answers[1],person:'daeun'};const r=E.submit(s,1,wrong);assert.equal(r.ok,false);assert.deepEqual(r.state.completed,[]);assert.equal(r.state.drafts[1].person,'daeun');assert.equal(r.state.attempts[0],1);
});
let completed=E.initial();completed.started=true;
check('All five stages, available sources and saved ending restore consistently',()=>{
 assert.equal(E.availableDocuments(completed).length,6);
 for(let id=1;id<=5;id++){const r=E.submit(completed,id,answers[id]);assert.ok(r.ok);completed=r.state;const restored=E.restore(JSON.parse(JSON.stringify(completed)));assert.deepEqual(restored.completed,completed.completed);assert.deepEqual(restored.answers,completed.answers);}
 assert.equal(E.availableDocuments(completed).length,18);assert.deepEqual(completed.completed,[1,2,3,4,5]);
});
check('Input normalization accepts human formatting and rejects incomplete answers',()=>{
 assert.ok(E.validateAnswer(2,{oldCell:'마 2',cell:'b1',address:'솔바람길18'}));assert.ok(E.validateAnswer(4,{...answers[4],order:'b → a → c → d'}));assert.ok(E.validateAnswer(1,{...answers[1],receipt:'9:50'}));
 for(let id=1;id<=5;id++){const invalid={...answers[id]};delete invalid[Object.keys(invalid)[0]];assert.equal(E.validateAnswer(id,invalid),false);assert.equal(E.validateAnswer(id,{}),false);}
});
check('Save imports reject other games, version mismatches and impossible progression',()=>{
 assert.throws(()=>E.restore({}));assert.throws(()=>E.restore({...completed,version:2}));assert.throws(()=>E.restore({...completed,completed:[2]}));
 assert.throws(()=>E.restore({...completed,answers:{...completed.answers,3:{...answers[3],back:'15:25'}}}));assert.throws(()=>E.restore({...completed,started:false}));
 const s=E.restore({...completed,notes:'x'.repeat(22000),pins:['missing','directory','directory'],hints:[9,-1,2,1,0],volume:9,playSeconds:Infinity});
 assert.equal(s.notes.length,20000);assert.deepEqual(s.pins,['directory']);assert.deepEqual(s.hints,[3,0,2,1,0]);assert.equal(s.volume,1);assert.equal(s.playSeconds,0);
});

function harness(saved,storageFailure=false){
 const events={},winEvents={},registered={},storage=new Map(saved?[[E.STORAGE,saved]]:[]),snapshots={},timers=[],maps={},captures={};
 const htmlNode=()=>({innerHTML:'',textContent:'',focus(){},scrollIntoView(){},classList:{add(){},remove(){}},addEventListener(){},querySelector(){return htmlNode();},getBoundingClientRect(){return {left:0,top:0,right:600,bottom:600}}});
 const app=htmlNode(),modal=htmlNode(),main=htmlNode(),toast=htmlNode();modal.open=false;modal.showModal=()=>{modal.open=true};modal.close=()=>{modal.open=false};
 const doc={hidden:false,modelContext:{registerTool(tool){registered[tool.name]=tool;}},body:{appendChild(){}},getElementById(id){return ({app,modal,main,toast})[id]||htmlNode();},querySelector(){return htmlNode();},querySelectorAll(selector){if(selector!=='.map-slot')return [];return [...app.innerHTML.matchAll(/class="map-slot" data-map="(old|current)"/g)].map(m=>{const el=htmlNode();el.dataset={map:m[1]};maps[m[1]]=el;return el;});},addEventListener(type,fn){(events[type]??=[]).push(fn)},createElement(){return {click(){},remove(){}}}};
 const sound={on:false,volume:.26,async setEnabled(on,v){this.on=on;this.volume=v;return on},setVolume(v){this.volume=v;}};
 const context={document:doc,console,Date,Math,JSON,Set,Map,String,Number,Object,Array,Promise,Blob,AbortController,URL:{createObjectURL(blob){captures.download=blob;return 'blob:test'},revokeObjectURL(){}},FormData:class{constructor(f){this.values=f.values||{};}entries(){return Object.entries(this.values)[Symbol.iterator]();}},localStorage:{getItem(k){if(storageFailure)throw Object.assign(new Error('blocked'),{name:'SecurityError'});return storage.get(k)||null},setItem(k,v){if(storageFailure)throw new Error('blocked');storage.set(k,v);}},setTimeout(fn){timers.push(fn);return timers.length},clearTimeout(){},setInterval(){return 1},clearInterval(){},scrollY:0,scrollTo(){},WIND_DATA:D,WIND_ENGINE:E,WIND_MUSIC:sound};
 context.window=context;context.addEventListener=(type,fn)=>{(winEvents[type]??=[]).push(fn);};vm.createContext(context);vm.runInContext(fs.readFileSync(path.join(__dirname,'dist/app.js'),'utf8'),context);
 async function click(action,data={}){const target={dataset:{action,...data},disabled:false,closest(sel){if(sel==='[data-action]')return target;if(sel==='.map-slot')return maps[data.era];return null}};for(const fn of events.click||[])await fn({target});}
 async function submit(id,values,data={}){const form={id,values,dataset:data};for(const fn of events.submit||[])await fn({target:form,preventDefault(){}});}
 async function input(id,value,extra={}){const target={id,value,...extra,closest(){return null}};for(const fn of events.input||[])await fn({target});}
 const getSave=()=>E.restore(JSON.parse(storage.get(E.STORAGE)));
 async function importText(text){for(const fn of events.change||[])await fn({target:{id:'import-file',files:[{size:text.length,text:async()=>text}]}});await Promise.resolve();}
 return {click,submit,input,importText,app,modal,storage,registered,sound,getSave,events,context,doc,snapshots,maps,captures};
}
async function uiTests(){
 async function start(h,values){await h.click('new-game');await h.click('prologue-next');await h.click('prologue-next');await h.submit('start-form',values);}
 const h=harness();check('UI opens directly on the game start screen',()=>assert.ok(h.app.innerHTML.includes('오늘의 편지 받기')));
 await h.click('new-game');check('Start control opens the immersive story in an accessible named dialog',()=>{assert.ok(h.modal.open);assert.ok(h.modal.innerHTML.includes('id="modal-title"'));assert.ok(h.modal.innerHTML.includes('바람이 이끈 문 앞에서'));assert.ok(h.modal.innerHTML.includes('prologue-image'));});h.snapshots.prologue1=h.modal.innerHTML;
 await h.submit('start-form',{name:'아직 시작 전'});
 check('Background pages cannot start or overwrite a game before the final step',()=>{assert.equal(h.storage.has(E.STORAGE),false);assert.ok(h.app.innerHTML.includes('오늘의 편지 받기'));});
 await h.click('prologue-next');
 check('The second scene explains the letters and the player role without revealing a solution',()=>{assert.ok(h.modal.innerHTML.includes('주소 대신 남아 있는 기억'));assert.ok(h.modal.innerHTML.includes('함께 보낸 기억'));assert.ok(h.modal.innerHTML.includes('기록 사이에'));assert.ok(!h.modal.innerHTML.includes('09:50'));});h.snapshots.prologue2=h.modal.innerHTML;
 await h.click('prologue-next');
 check('The final scene explains how to investigate and deliver before offering the start form',()=>{for(const s of ['업무 책상','기록 열람실','조사 수첩','배달표','우표','첫 번째 업무','start-form'])assert.ok(h.modal.innerHTML.includes(s));});
 await h.input('player-name','빛나는 여행자');await h.input('prologue-music','on',{checked:false});await h.click('prologue-back');await h.click('prologue-next');
 check('Going back through the story preserves the name and music draft',()=>{assert.ok(h.modal.innerHTML.includes('value="빛나는 여행자"'));assert.ok(!/<input id="prologue-music"[^>]*checked/.test(h.modal.innerHTML));});h.snapshots.prologue3=h.modal.innerHTML;
 await h.submit('start-form',{name:'<img src=x onerror=alert(1)>',music:undefined});
 check('Start enters the play area and escapes user-supplied names',()=>{assert.ok(h.app.innerHTML.includes('업무 책상'));assert.ok(!h.app.innerHTML.includes('<img src=x'));assert.equal(h.getSave().started,true);});
 await h.click('document',{id:'receipts'});await h.click('pin',{id:'receipts'});await h.click('nav',{view:'notebook'});await h.input('notes','09:50 ↔ 무화과빵\n<script>unsafe()</script>');await h.submit('connection-form',{from:'receipts',to:'bakery-menu',note:'가격을 시각에 연결'});
 check('Read records, pins, multiline notes and clue connections persist',()=>{const s=h.getSave();assert.ok(s.read.includes('receipts'));assert.ok(s.pins.includes('receipts'));assert.equal(s.connections.length,1);assert.ok(s.notes.includes('\n'));assert.ok(h.app.innerHTML.includes('&lt;script&gt;'));assert.ok(!h.app.innerHTML.includes('<script>unsafe'));});
 await h.click('hint',{id:'1'});await h.click('reveal-hint',{id:'1'});check('Hints reveal one stage at a time and persist',()=>{assert.equal(h.getSave().hints[0],1);assert.ok(h.modal.innerHTML.includes('1단계 · 볼 곳'));assert.ok(!h.modal.innerHTML.includes('3단계 · 풀이와 정답'));});
 await h.click('answer',{id:'1'});await h.submit('answer-form',{...answers[1],person:'daeun'},{letter:'1'});
 check('Wrong delivery remains in the form and keeps the drafted answer',()=>{assert.equal(h.getSave().completed.length,0);assert.ok(h.modal.innerHTML.includes('role="alert"'));assert.ok(h.modal.innerHTML.includes('value="daeun" selected'));});
 await h.submit('answer-form',answers[1],{letter:'1'});
 check('First correct delivery shows a reply, postcard and next letter control',()=>{assert.equal(h.getSave().completed.length,1);assert.ok(h.app.innerHTML.includes('해준의 감사 엽서'));assert.ok(h.app.innerHTML.includes('다음 편지 열기'));});
 const beforeStory=h.storage.get(E.STORAGE);await h.click('new-game');await h.click('prologue-next');await h.click('close-modal');
 check('Closing the story midway preserves existing progress and notes',()=>assert.equal(h.storage.get(E.STORAGE),beforeStory));
 await h.click('help');await h.click('prologue-replay');await h.click('prologue-next');await h.click('prologue-next');await h.submit('start-form',{name:'덮어쓰지 않기'});
 check('Story replay has no reset form and cannot replace an existing game',()=>{assert.ok(!h.modal.innerHTML.includes('id="start-form"'));assert.equal(h.storage.get(E.STORAGE),beforeStory);assert.ok(h.modal.innerHTML.includes('이야기를 접어 두기'));});await h.click('close-modal');
 await h.click('nav',{view:'records'});h.snapshots.records=h.app.innerHTML;
 await h.click('nav',{view:'map'});await h.click('map-cell',{era:'current',cell:'B1'});
 check('Current map renders 25 selectable cells and the correct B1 address',()=>{assert.equal((h.maps.current.innerHTML.match(/data-action="map-cell"/g)||[]).length,25);assert.ok(h.maps.current.innerHTML.includes('솔바람길 18'));});h.snapshots.map=h.maps.current.innerHTML;
 await h.click('map-era',{era:'old'});await h.click('map-cell',{era:'old',cell:'마2'});
 check('Old map keeps its original coordinate system without revealing transformed addresses',()=>{assert.equal((h.maps.old.innerHTML.match(/data-action="map-cell"/g)||[]).length,25);assert.ok(h.maps.old.innerHTML.includes('옛 좌표 마2'));assert.ok(!h.maps.old.innerHTML.includes('솔바람길 18'));});h.snapshots.oldMap=h.maps.old.innerHTML;
 for(let id=2;id<=4;id++)await h.submit('answer-form',answers[id],{letter:String(id)});
 await h.click('cards');check('Four completed deliveries expose all four meta-puzzle postcards',()=>{assert.equal((h.app.innerHTML.match(/class="postcard"/g)||[]).length,4);assert.ok(h.app.innerHTML.includes('초대장 배달표 작성'));});h.snapshots.cards=h.app.innerHTML;
 await h.click('letter',{id:'5'});h.snapshots.desk=h.app.innerHTML;await h.click('answer',{id:'5'});h.snapshots.answer=h.modal.innerHTML;
 await h.submit('answer-form',answers[5],{letter:'5'});
 check('Fifth delivery reaches and saves the ending',()=>{assert.deepEqual(h.getSave().completed,[1,2,3,4,5]);assert.ok(h.app.innerHTML.includes('오늘은 당신도'));assert.ok(h.app.innerHTML.includes('오후 6시 40분'));});h.snapshots.ending=h.app.innerHTML;
 const saved=h.storage.get(E.STORAGE),resumed=harness(saved);await resumed.click('continue');
 check('Reload and continue restore the ending and notebook',()=>{assert.ok(resumed.app.innerHTML.includes('오늘은 당신도'));assert.equal(resumed.getSave().connections.length,1);});
 await h.click('settings');await h.input('volume','12');await h.click('music');
 check('Music toggle and volume use the saved settings',()=>{assert.equal(h.sound.on,true);assert.equal(h.sound.volume,.12);assert.equal(h.getSave().music,true);});
 await h.click('export');const exported=await h.captures.download.text();check('Exported progress is a restorable JSON file with the saved ending',()=>{assert.equal(E.restore(JSON.parse(exported)).completed.length,5);assert.equal(h.getSave().completed.length,5);});
 const importer=harness();await start(importer,{name:'현재 여행자'});await importer.importText(exported);
 check('Import preview leaves existing progress unchanged until confirmed',()=>{assert.equal(importer.getSave().completed.length,0);assert.ok(importer.modal.innerHTML.includes('이 기록 불러오기'));});
 await importer.click('confirm-import');check('Confirm import restores the visible ending and notes',()=>{assert.equal(importer.getSave().completed.length,5);assert.ok(importer.app.innerHTML.includes('오늘은 당신도'));assert.ok(importer.getSave().notes.includes('무화과빵'));});
 await importer.importText('{bad json');check('Invalid file import preserves existing progress',()=>assert.equal(importer.getSave().completed.length,5));
 await importer.click('new-game');check('Opening the new-game dialog preserves saved progress',()=>assert.equal(importer.getSave().completed.length,5));
 await importer.click('prologue-next');await importer.click('prologue-next');
 await importer.submit('start-form',{name:'새 집배원'});check('Confirmed new game resets only this game and starts at the first letter',()=>{assert.equal(importer.getSave().completed.length,0);assert.equal(importer.getSave().notes,'');assert.ok(importer.app.innerHTML.includes('빵 봉투를 먼저 챙겨 준 분께'));});
 check('WebMCP tools register and validate their inputs through a mock registry',()=>{assert.equal(Object.keys(h.registered).length,3);const p=h.registered.read_post_office_progress.execute({});assert.equal(p.completed.length,5);assert.throws(()=>h.registered.open_post_office_document.execute({id:'absent'}));const r=h.registered.open_post_office_document.execute({id:'directory'});assert.equal(r.opened,'directory');assert.throws(()=>h.registered.submit_post_office_delivery.execute({letter:9,answer:{}}));});
 const locked=harness();await start(locked,{name:'검증'});
 check('WebMCP cannot navigate to locked records or submit future puzzles',()=>{assert.throws(()=>locked.registered.open_post_office_document.execute({id:'oven'}));assert.throws(()=>locked.registered.submit_post_office_delivery.execute({letter:5,answer:answers[5]}));assert.equal(locked.getSave().completed.length,0);});
 check('Malformed storage shows a recoverable message',()=>{const bad=harness('{no json');assert.ok(bad.app.innerHTML.includes('기존 저장 정보를 읽지 못했어요'));});
 const blocked=harness(null,true);await start(blocked,{name:'저장 제한'});
 check('Unavailable browser storage keeps the game playable and explains file saving',()=>{assert.ok(blocked.app.innerHTML.includes('진행 파일로 저장해 주세요'));assert.ok(blocked.app.innerHTML.includes('배달표 작성'));});
 fs.mkdirSync(path.join(__dirname,'qa'),{recursive:true});
 for(const [name,html]of Object.entries(h.snapshots))fs.writeFileSync(path.join(__dirname,'qa',name+'.html'),html);
 fs.writeFileSync(path.join(__dirname,'qa','solved-answers.json'),JSON.stringify(answers,null,2));
 console.log(`\n${checks} verification groups passed. Real browser layout and audio playback were not tested.`);
}
uiTests().catch(e=>{console.error(e);process.exitCode=1;});
